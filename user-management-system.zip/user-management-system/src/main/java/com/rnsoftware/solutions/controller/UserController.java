package com.rnsoftware.solutions.controller;

import com.rnsoftware.solutions.utility.ExcelGenerator;
import com.rnsoftware.solutions.utility.PdfGenerator;
import com.rnsoftware.solutions.model.User;
import com.rnsoftware.solutions.repository.UserRepository;
import com.rnsoftware.solutions.service.UserService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.List;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Controller
public class UserController {
    private final UserRepository userRepository;
    @Value("${upload.path}")
    private String uploadDir;
    private final UserService userService;
    public UserController(UserRepository userRepository, UserService userService) {
        this.userRepository = userRepository;
        this.userService = userService;
    }

    @GetMapping("/")
    public String home(Model model) {
        List<User> users = userRepository.findAll();
        long userCount = userRepository.count();
        model.addAttribute("users", users);
        model.addAttribute("userCount", userCount);
        return "users";
    }

    @GetMapping("/add")
    public String addForm(Model model) {
        model.addAttribute("user", new User());
        return "add_user";
    }

    @PostMapping("/save")
    public String saveUser(@ModelAttribute User user,
                           @RequestParam("photoFile") MultipartFile photoFile) throws IOException {

        if (!photoFile.isEmpty()) {
            String systemUploadPath = System.getProperty("user.home") + File.separator + "uploads";

            File uploadFolder = new File(systemUploadPath);
            if (!uploadFolder.exists()) {
                uploadFolder.mkdirs();
            }
            String fileName = UUID.randomUUID() + "_" + photoFile.getOriginalFilename();
            File destinationFile = new File(uploadFolder, fileName);
            photoFile.transferTo(destinationFile);
            user.setPhoto(fileName);
        }
        userRepository.save(user);
        return "redirect:/";
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        long totalUsers = userRepository.count();
        model.addAttribute("totalUsers", totalUsers);
        return "dashboard";
    }

    @PostMapping("/update")
    public String updateUser(@ModelAttribute User user,
                             @RequestParam("photoFile") MultipartFile photoFile) throws IOException {
        User existing = userRepository.findById(user.getId())
                .orElseThrow(() -> new IllegalArgumentException("User not found"));

        if (!photoFile.isEmpty()) {
            String absolutePath = new File("src/main/resources/static/uploads").getAbsolutePath();

            File uploadFolder = new File(absolutePath);
            if (!uploadFolder.exists()) {
                uploadFolder.mkdirs();
            }

            // Save file
            String fileName = UUID.randomUUID() + "_" + photoFile.getOriginalFilename();
            File destination = new File(uploadFolder, fileName);
            photoFile.transferTo(destination);

            user.setPhoto(fileName);
        } else {
            user.setPhoto(existing.getPhoto());
        }
        userRepository.save(user);
        return "redirect:/";
    }

    @GetMapping("/edit/{id}")
    public String editUser(@PathVariable Long id, Model model) {
        User user = userRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid user ID: " + id));
        model.addAttribute("user", user);
        return "edit_user";
    }

    // Download photos
    @GetMapping("/download-all-photos")
    public ResponseEntity<InputStreamResource> downloadAllPhotos() throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ZipOutputStream zipOut = new ZipOutputStream(byteArrayOutputStream);

        for (User user : userRepository.findAll()) {
            if (user.getPhoto() != null) {
                File photoFile = new File(uploadDir + File.separator + user.getPhoto());
                if (photoFile.exists()) {
                    FileInputStream fis = new FileInputStream(photoFile);
                    zipOut.putNextEntry(new ZipEntry(user.getPhoto()));
                    byte[] bytes = new byte[1024];
                    int length;
                    while ((length = fis.read(bytes)) >= 0) {
                        zipOut.write(bytes, 0, length);
                    }
                    fis.close();
                    zipOut.closeEntry();
                }
            }
        }
        zipOut.close();
        InputStreamResource resource = new InputStreamResource(new ByteArrayInputStream(byteArrayOutputStream.toByteArray()));
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=all_user_photos.zip")
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(resource);
    }

    // generate excel
    @GetMapping("/export-excel")
    public void exportToExcel(HttpServletResponse response) throws IOException {
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename=users.xlsx");

        List<User> users = userService.getAllUsers();
        ExcelGenerator.generateExcel(users, response.getOutputStream());
    }

    // generate pdf
    @GetMapping("/export-pdf")
    public void exportToPdf(HttpServletResponse response) throws IOException {
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=users.pdf");

        List<User> users = userService.getAllUsers();
        PdfGenerator.generatePdf(users, response.getOutputStream());
    }

    @GetMapping("/delete/{id}")
    public String deleteUser(@PathVariable Long id) {
        userRepository.deleteById(id);
        return "redirect:/";
    }
}
