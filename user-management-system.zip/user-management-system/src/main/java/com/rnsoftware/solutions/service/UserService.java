package com.rnsoftware.solutions.service;

import com.rnsoftware.solutions.model.User;

import java.util.List;

public interface UserService {
    List<User> getAllUsers();
}
