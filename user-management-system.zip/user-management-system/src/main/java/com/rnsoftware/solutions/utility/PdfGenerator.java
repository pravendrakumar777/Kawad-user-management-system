package com.rnsoftware.solutions.utility;

import com.lowagie.text.*;
import com.lowagie.text.Font;
import com.lowagie.text.Image;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.rnsoftware.solutions.model.User;

import java.awt.*;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import java.util.List;
import java.util.stream.Stream;

public class PdfGenerator {
    public static void generatePdf(List<User> users, OutputStream outputStream) throws IOException {
        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, outputStream);
        document.open();

        PdfPTable headerTable = new PdfPTable(3);
        headerTable.setWidthPercentage(100);
        headerTable.setWidths(new float[]{1f, 2f, 1f});

        try {
            // Load left logo
            Image logo = null;
            URL logoUrl = PdfGenerator.class.getResource("/static/images/shiva-shivling.jpg");
            if (logoUrl != null) {
                logo = Image.getInstance(logoUrl);
                logo.scaleToFit(60, 60);
            }

            // Load right QR
            Image qr = null;
            URL qrUrl = PdfGenerator.class.getResource("/static/images/shiva-naag.jpg");
            if (qrUrl != null) {
                qr = Image.getInstance(qrUrl);
                qr.scaleToFit(60, 60);
            }

            // Logo cell
            PdfPCell logoCell = new PdfPCell();
            if (logo != null) {
                logoCell.addElement(logo);
            }
            logoCell.setBorder(Rectangle.NO_BORDER);
            logoCell.setHorizontalAlignment(Element.ALIGN_LEFT);

            // Title cell
            Font titleFont = new Font(Font.HELVETICA, 18, Font.BOLD);
            Paragraph title = new Paragraph("User List", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);

            PdfPCell titleCell = new PdfPCell();
            titleCell.addElement(title);
            titleCell.setBorder(Rectangle.NO_BORDER);
            titleCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            titleCell.setHorizontalAlignment(Element.ALIGN_CENTER);

            // QR cell
            PdfPCell qrCell = new PdfPCell();
            if (qr != null) {
                qrCell.addElement(qr);
            }
            qrCell.setBorder(Rectangle.NO_BORDER);
            qrCell.setHorizontalAlignment(Element.ALIGN_RIGHT);

            // Add cells to header table
            headerTable.addCell(logoCell);
            headerTable.addCell(titleCell);
            headerTable.addCell(qrCell);

            document.add(headerTable);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Add spacing after header
        document.add(new Paragraph("\n"));

        // Table with user data
        PdfPTable table = new PdfPTable(7);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10f);

        // Header row
        Stream.of("ID", "First Name", "Last Name", "Email", "Mobile", "Gender", "Address")
                .forEach(column -> {
                    PdfPCell cell = new PdfPCell(new Phrase(column));
                    cell.setBackgroundColor(Color.LIGHT_GRAY);
                    table.addCell(cell);
                });

        // Data rows
        for (User user : users) {
            table.addCell(String.valueOf(user.getId()));
            table.addCell(user.getFirstName());
            table.addCell(user.getLastName());
            table.addCell(user.getEmail());
            table.addCell(user.getMobile());
            table.addCell(user.getGender());
            table.addCell(user.getAddress());
        }

        document.add(table);
        document.close();
    }
}